import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {parse,filename,safeName} from '../parser.mjs';
const entry=(n=1,start='00:00:00.000',end='00:00:05.000')=>`IMAGE ${String(n).padStart(3,'0')}\nTIME: ${start} --> ${end}\n\nPROMPT:\nA clean white desk.\n\n---\n\n`;
test('parses CRLF, BOM, separators and final short interval',()=>{
 const frames=parse('\uFEFF---\r\n'+(entry()+entry(2,'00:00:05.000','00:00:05.360')).replaceAll('\n','\r\n'));
 assert.equal(frames.length,2);assert.equal(frames[1].end,'00:00:05.360');assert.equal(frames[0].prompt,'A clean white desk.');
 assert.equal(filename(frames[0]),'FRAME_001__00-00-00-000__00-00-05-000.png');
});
test('rejects duplicates, gaps, overlaps, bad timestamps and master text',()=>{
 for(const input of [entry()+entry(),entry()+entry(2,'00:00:06.000','00:00:10.000'),entry()+entry(2,'00:00:04.000','00:00:10.000'),entry(1,'00:61:00.000'),entry(1,'00:00:06.000'), 'Master prompt instructions'])assert.throws(()=>parse(input));
});
test('safe folder names and Persian names',()=>{
 assert.equal(safeName('my/video:frames'),'my_video_frames');assert.equal(safeName('تصاویر رضا'),'تصاویر رضا');
 for(const value of ['..','CON','nul.txt','  '])assert.throws(()=>safeName(value));
});
if(process.env.REZA_INPUT)test('entire user file: 160 sequential entries, correct end and preserved prompts',()=>{
 const frames=parse(readFileSync(process.env.REZA_INPUT,'utf8'));assert.equal(frames.length,160);
 frames.forEach((f,i)=>{assert.equal(f.number,i+1);assert.ok(f.prompt.includes('no humans'));assert.ok(!f.prompt.endsWith('---'));});
 assert.equal(frames.at(-1).end,'00:13:15.360');
});
