import test from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import {readFileSync} from 'node:fs';
const code=readFileSync(new URL('../content.js',import.meta.url),'utf8');
function harness(messages){let listener;const context={location:{href:'https://chatgpt.com/c/test'},chrome:{storage:{local:{get:async()=>({})}},runtime:{id:'extension',onMessage:{addListener:fn=>listener=fn}}},document:{querySelectorAll:()=>messages,querySelector:()=>null},setTimeout,Promise};vm.runInNewContext(code,context);return m=>new Promise(resolve=>listener(m,{id:'extension'},resolve));}
const msg=(role,text,images=[],id=null)=>({id,dataset:{messageAuthorRole:role},textContent:text,matches:()=>true,getAttribute:name=>name==='data-message-author-role'?role:null,querySelector:()=>null,closest:()=>null,querySelectorAll:()=>images});
const img=url=>({complete:true,naturalWidth:1024,naturalHeight:1024,src:url});
test('only selects image belonging to requested user turn',async()=>{
 const send=harness([msg('user','old'),msg('assistant','',[img('old.png')]),msg('user','REZA_target'),msg('assistant','',[img('target.png')]),msg('user','later'),msg('assistant','',[img('later.png')])]);
 const r=await send({type:'inspect',marker:'REZA_target'});assert.equal(r.images.length,1);assert.equal(r.images[0].url,'target.png');
});
test('missing marker cannot match an old image',async()=>{
 const r=await harness([msg('assistant','',[img('old.png')])])({type:'inspect',marker:'absent'});assert.equal(r.found,false);
});
test('same request is not sent twice',async()=>{
 const r=await harness([msg('user','REZA_target')])({type:'send',marker:'REZA_target',prompt:'anything'});assert.equal(r.alreadySent,true);
});
test('small avatars are excluded',async()=>{
 const avatar={...img('avatar'),naturalWidth:64};
 const r=await harness([msg('user','target'),msg('assistant','',[avatar])])({type:'inspect',marker:'target'});assert.equal(r.images.length,0);
});
function flowHarness({images=[],page='https://labs.google/fx/tools/flow/project/test',bindings={results:'#results'}}={}){
 let listener;const root={querySelectorAll:()=>images,querySelector:()=>null};
 const context={location:{href:page},URL,chrome:{storage:{local:{get:async()=>({bindings:{flow:bindings}})}},runtime:{id:'extension',onMessage:{addListener:fn=>listener=fn}}},document:{querySelector:s=>s==='#results'?root:null},setTimeout,Promise};
 vm.runInNewContext(code,context);
 return m=>new Promise(resolve=>listener({provider:'flow',...m},{id:'extension'},resolve));
}
test('Flow excludes existing images and normalizes signed URL credentials',async()=>{
 const old=img('https://lh3.googleusercontent.com/old?Signature=new&Expires=999'),fresh=img('https://lh3.googleusercontent.com/new');
 const send=flowHarness({images:[old,fresh]});
 const r=await send({type:'inspect',context:{page:'https://labs.google/fx/tools/flow/project/test',before:['https://lh3.googleusercontent.com/old']}});
 assert.equal(r.ok,true);assert.equal(r.images.length,1);assert.equal(r.images[0].url,fresh.src);
});
test('Flow refuses recovery in a different project',async()=>{
 const r=await flowHarness()({type:'inspect',context:{page:'https://labs.google/fx/tools/flow/project/other',before:[]}});
 assert.equal(r.ok,false);assert.match(r.error,/original Flow project/);
});
test('Flow refuses uncalibrated result selection',async()=>{
 const r=await flowHarness({bindings:{}})({type:'prepare'});assert.equal(r.ok,false);assert.match(r.error,/Map controls/);
});
test('Flow snapshots unloaded image URLs too',async()=>{
 const r=await flowHarness({images:[{complete:false,src:'https://lh3.googleusercontent.com/old'}]})({type:'prepare'});
 assert.equal(r.context.before[0],'https://lh3.googleusercontent.com/old');
});
test('recovers existing v2 pending request by exact prompt when token is absent',async()=>{
 const send=harness([msg('user','Generate one image: A unique green desk.',[],'u1'),msg('assistant','',[img('new.png')],'a1')]);
 const r=await send({type:'inspect',marker:'missing-old-token',prompt:'A unique green desk.'});
 assert.equal(r.found,true);assert.equal(r.context.userId,'u1');assert.equal(r.images[0].url,'new.png');
});
test('uses acknowledged user ID when ChatGPT collapses request text',async()=>{
 const r=await harness([msg('user','[collapsed]',[],'u2'),msg('assistant','',[img('frame2.png')],'a2')])({type:'inspect',marker:'hidden',context:{userId:'u2',chatPage:'https://chatgpt.com/c/test'}});
 assert.equal(r.found,true);assert.equal(r.images[0].url,'frame2.png');
});
test('retains tracked assistant if user turn is unmounted',async()=>{
 const r=await harness([msg('assistant','',[img('frame2.png')],'a2')])({type:'inspect',marker:'hidden',context:{userId:'u2',assistantId:'a2',chatPage:'https://chatgpt.com/c/test'}});
 assert.equal(r.found,true);assert.equal(r.images[0].url,'frame2.png');
});
test('rejects wrong conversation even if IDs coincide',async()=>{
 const r=await harness([msg('user','token',[],'u1')])({type:'inspect',marker:'token',context:{chatPage:'https://chatgpt.com/c/other'}});assert.equal(r.ok,false);assert.match(r.error,/conversation/);
});
test('prompt recovery excludes a previously snapshotted identical prompt',async()=>{
 const r=await harness([msg('user','same prompt',[],'old'),msg('assistant','',[img('old.png')]),msg('user','same prompt',[],'new'),msg('assistant','',[img('new.png')])])({type:'inspect',marker:'hidden',prompt:'same prompt',context:{beforeIds:['old']}});
 assert.equal(r.found,true);assert.equal(r.images[0].url,'new.png');
});
test('ambiguous repeated prompt never guesses a frame',async()=>{
 const r=await harness([msg('user','same prompt'),msg('user','same prompt')])({type:'inspect',marker:'hidden',prompt:'same prompt'});assert.equal(r.found,false);
});
test('supports article data-turn layout without legacy message-role elements',async()=>{
 const article=(role,text,images,id)=>({id,dataset:{},textContent:text,closest:()=>null,matches:()=>false,getAttribute:n=>n==='data-turn'?role:null,querySelector:()=>null,querySelectorAll:()=>images});
 const r=await harness([article('user','token',[],'u'),article('assistant','',[img('new.png')],'a')])({type:'inspect',marker:'token'});
 assert.equal(r.found,true);assert.equal(r.images[0].url,'new.png');
});
test('empty ChatGPT auto setup ignores stale mappings, waits for Send, and handles three frames',async()=>{
 let listener;const messages=[];
 class Editor{constructor(){this.text='';this.tagName='TEXTAREA';}get value(){return this.text;}set value(v){this.text=v;}focus(){}dispatchEvent(){}getClientRects(){return [1];}}
 const editor=new Editor();let count=0,buttonPolls=0,voiceClicks=0,settingsReads=0;
 const button={disabled:false,getClientRects:()=>[1],getAttribute:()=>null,click(){const n=++count;messages.push(msg('user',editor.value,[],'u'+n),msg('assistant','',[img('frame'+n+'.png')],'a'+n));editor.value='';}};
 const context={location:{href:'https://chatgpt.com/c/test'},URL,HTMLTextAreaElement:Editor,Event:class{},setTimeout:fn=>{queueMicrotask(fn);},Promise,
  chrome:{storage:{local:{get:async()=>{settingsReads++;return {bindings:{chatgpt:{button:'#voice'}}};}}},runtime:{id:'extension',onMessage:{addListener:fn=>listener=fn}}},
  document:{querySelectorAll:s=>s.startsWith('#prompt-textarea')?[editor]:messages,querySelector:s=>s==='#prompt-textarea'?editor:s==='#voice'?{click(){voiceClicks++;}}:s.startsWith('[data-testid="send-button"]')&&editor.value&&++buttonPolls>=3?button:null}};
 vm.runInNewContext(code,context);
 const call=m=>new Promise(resolve=>listener({provider:'chatgpt',...m},{id:'extension'},resolve));
 for(let n=1;n<=3;n++){
  buttonPolls=0;
  const probe=await call({type:'probe'});assert.equal(probe.composer,true);assert.equal(probe.button,false);
  const prepared=await call({type:'prepare'});
  const sent=await call({type:'send',marker:'token'+n,prompt:'A unique desk '+n,context:prepared.context});
  assert.equal(sent.ok,true,sent.error);assert.equal(sent.context.userId,'u'+n);
  // Simulate a collapsed user bubble after generation while preserving its ID.
  messages.at(-2).textContent='[collapsed]';
  const found=await call({type:'inspect',marker:'token'+n,prompt:'A unique desk '+n,context:sent.context});
  assert.equal(found.images[0].url,'frame'+n+'.png');
 }
 assert.equal(count,3);assert.equal(voiceClicks,0);assert.equal(settingsReads,0);
});
test('ChatGPT calibration is automatic and never opens a control picker',async()=>{
 const result=await harness([])({type:'calibrate',provider:'chatgpt'});
 assert.equal(result.ok,true);assert.equal(result.automatic,true);
});
function richHarness(initialDraft=''){
 let listener,clicks=0,insertions=0,lastFilled='';const messages=[];
 const makeEditor=text=>({tagName:'DIV',innerText:text,focus(){},dispatchEvent(){},getClientRects:()=>[1]});
 let live=makeEditor(initialDraft);
 const button={disabled:false,getClientRects:()=>[1],getAttribute:()=>null,click(){clicks++;messages.push(msg('user',live.innerText,[],'rich-u'),msg('assistant','',[img('rich.png')],'rich-a'));live=makeEditor('');}};
 const context={location:{href:'https://chatgpt.com/c/test'},URL,InputEvent:class{},setTimeout:fn=>queueMicrotask(fn),Promise,
  window:{getSelection:()=>({removeAllRanges(){},addRange(){}})},
  chrome:{runtime:{id:'extension',onMessage:{addListener:fn=>listener=fn}}},
  document:{querySelectorAll:s=>s.startsWith('#prompt-textarea')?[live]:messages,
   querySelector:s=>s.startsWith('[data-testid="send-button"]')?button:null,
   createRange:()=>({selectNodeContents(){}}),
   execCommand(command,unused,text){insertions++;lastFilled=text;live=makeEditor(text.replace(/\n/g,'\n\n'));return true;}
  }};
 vm.runInNewContext(code,context);
 return {call:m=>new Promise(resolve=>listener({provider:'chatgpt',...m},{id:'extension'},resolve)),get clicks(){return clicks;},get insertions(){return insertions;},get lastFilled(){return lastFilled;},get draft(){return live.innerText;}};
}
test('rich-text paragraph breaks and replacement editor do not cause false rejection',async()=>{
 const h=richHarness();const r=await h.call({type:'send',marker:'rich-token',prompt:'A desk.\nWhite background.'});
 assert.equal(r.ok,true,r.error);assert.equal(r.sent,true);assert.equal(h.clicks,1);assert.equal(h.insertions,1);
});
test('Resume submits matching legacy draft once without appending or refilling',async()=>{
 const first=richHarness();await first.call({type:'send',marker:'recover-token',prompt:'A desk.'});
 const h=richHarness(first.lastFilled.replace(/\n/g,'\n\n'));
 const request={type:'recover',marker:'recover-token',prompt:'A desk.'};
 const r=await h.call(request);assert.equal(r.ok,true,r.error);assert.equal(r.sent,true);assert.equal(h.insertions,0);assert.equal(h.clicks,1);
 const again=await h.call(request);assert.equal(again.alreadySent,true);assert.equal(h.clicks,1);
});
test('Resume never fills an empty composer or sends a different draft',async()=>{
 for(const text of ['', 'My unrelated draft']){
  const h=richHarness(text),r=await h.call({type:'recover',marker:'unknown',prompt:'A desk.'});
  assert.equal(r.pending,true);assert.equal(h.clicks,0);assert.equal(h.insertions,0);assert.equal(h.draft,text);
 }
});
function workHarness(){
 const marker='DRCOMP_batch_1_abc';
 const el=(order,text,excluded=false)=>({order,innerText:text,textContent:text,getClientRects:()=>[1],closest:()=>excluded?{}:null,compareDocumentPosition(other){return other.order>order?4:2;}});
 const request=el(1,'[DrComp frame '+marker+']'),repeat=el(2,'Tracking '+marker),later=el(5,'[DrComp frame DRCOMP_batch_2_xyz]');
 const image=(order,url,excluded=false)=>Object.assign(el(order,'',excluded),img(url));
 const images=[image(0,'old.png'),image(3,'target.png'),image(4,'sidebar.png',true),image(6,'later.png')];
 const textNodes=[request,repeat,later].map(e=>({nodeValue:e.innerText,parentElement:e}));
 const scope={querySelectorAll:()=>images};let listener;
 const context={location:{href:'https://chatgpt.com/c/work'},URL,NodeFilter:{SHOW_TEXT:4},Node:{DOCUMENT_POSITION_FOLLOWING:4},
 chrome:{runtime:{id:'extension',onMessage:{addListener:fn=>listener=fn}}},
 document:{body:scope,querySelector:s=>s==='main'?scope:null,querySelectorAll:()=>[],createTreeWalker:()=>{let i=0;return {nextNode:()=>textNodes[i++]||null};}}};
 vm.runInNewContext(code,context);
 return {marker,call:m=>new Promise(resolve=>listener({provider:'chatgpt',...m},{id:'extension'},resolve))};
}
test('Work layout: finds request without role attributes; ignores prior, sidebar and later-frame images',async()=>{
 const h=workHarness(),r=await h.call({type:'inspect',marker:h.marker,prompt:'A workstation.',context:{beforeImages:['old.png']}});
 assert.equal(r.ok,true,r.error);assert.equal(r.found,true);assert.equal(r.context.layout,'work');assert.equal(r.images.length,1);assert.equal(r.images[0].url,'target.png');
});
test('Work layout never selects an image when the requested anchor is absent',async()=>{
 const h=workHarness(),r=await h.call({type:'inspect',marker:'DRCOMP_missing',prompt:'An unrelated prompt.'});
 assert.equal(r.found,false);
});
