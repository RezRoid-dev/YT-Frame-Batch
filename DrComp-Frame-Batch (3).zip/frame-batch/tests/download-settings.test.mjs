import test from 'node:test';import assert from 'node:assert/strict';import {applyAutomaticDownloads,siteOrigin} from '../download-settings.mjs';
function mock(blocked=false){const saved={},rules={};return {rules,storage:{local:{get:async()=>saved,set:async s=>Object.assign(saved,s)}},contentSettings:{automaticDownloads:{clear:async()=>{for(const k of Object.keys(rules))delete rules[k];},set:async r=>{rules[r.primaryPattern]=r.setting;},get:async({primaryUrl})=>({setting:blocked?'block':rules[new URL(primaryUrl).origin+'/*']||'ask'})}}};}
test('enables site-only downloads and removes only the chosen extension rule',async()=>{
 const c=mock();assert.equal(await applyAutomaticDownloads(c,'https://chatgpt.com/c/a',true),'allow');
 await applyAutomaticDownloads(c,'https://labs.google/fx/tools/flow',true);await applyAutomaticDownloads(c,'https://chatgpt.com/',false);
 assert.deepEqual(c.rules,{'https://labs.google/*':'allow'});
});
test('managed block is reported and previous rules are restored',async()=>{
 const c=mock(true);await assert.rejects(()=>applyAutomaticDownloads(c,'https://chatgpt.com/',true),/policy/);assert.deepEqual(c.rules,{});
});
test('never creates global rules or rules for unrelated sites',()=>{
 for(const url of ['https://example.com/','http://chatgpt.com/','chrome://settings/'])assert.throws(()=>siteOrigin(url));
});
