const {chromium}=require('playwright');
const path=require('path');const fs=require('fs');const assert=require('node:assert/strict');
(async()=>{
 const root=path.resolve(__dirname,'..'),out=path.resolve(process.env.REZA_QA_DIR||'qa');fs.mkdirSync(out,{recursive:true});
 const context=await chromium.launchPersistentContext(path.join(out,'profile'),{headless:true,channel:'chromium',acceptDownloads:true,downloadsPath:path.join(out,'downloads'),args:[`--disable-extensions-except=${root}`,`--load-extension=${root}`],viewport:{width:400,height:1000}});
 try{
  const worker=context.serviceWorkers()[0]||await context.waitForEvent('serviceworker');const id=new URL(worker.url()).host;
  const behavior=await worker.evaluate(()=>chrome.sidePanel.getPanelBehavior());assert.equal(behavior.openPanelOnActionClick,true);
  const fixture=(flow)=>`<!doctype html><html><body><main><div id="results"></div><textarea id="${flow?'flow-prompt':'prompt-textarea'}" placeholder="Describe image"></textarea><button id="generate" ${flow?'aria-label="Generate"':'data-testid="send-button"'}>Generate</button></main><script>
   window.count=0;function png(color){const c=document.createElement('canvas');c.width=512;c.height=288;c.getContext('2d').fillStyle=color;c.getContext('2d').fillRect(0,0,512,288);return c.toDataURL('image/png');}
   ${flow?`const old=document.createElement('img');old.src=png('red');document.querySelector('#results').append(old);`:''}
   document.querySelector('button').onclick=()=>{window.count++;const editor=document.querySelector('textarea');const text=editor.value;editor.value='';const image=document.createElement('img');image.src=png('green');
   ${flow?`document.querySelector('#results').append(image);`:`const u=document.createElement('div');u.dataset.messageAuthorRole='user';u.textContent=text;const a=document.createElement('div');a.dataset.messageAuthorRole='assistant';a.append(image);document.querySelector('#results').append(u,a);`}};
   </script></body></html>`;
  await context.route('https://chatgpt.com/**',r=>r.fulfill({contentType:'text/html',body:fixture(false)}));
  await context.route('https://labs.google/**',r=>r.fulfill({contentType:'text/html',body:fixture(true)}));
  const site=await context.newPage();await site.goto('https://chatgpt.com/c/fixture');
  const panel=await context.newPage();await panel.goto(`chrome-extension://${id}/dashboard.html`);
  panel.on('dialog',d=>d.accept());
  await panel.locator('#refresh').click();await panel.locator('#connect').click();
  await panel.waitForFunction(()=>document.querySelector('#status').textContent==='Connection ready.');
  await panel.locator('#file').setInputFiles(path.join(root,'sample-prompts.txt'));
  await panel.locator('#folder').fill('Fixture-ChatGPT');await panel.locator('#start').click();
  await panel.waitForFunction(()=>document.querySelector('#status').textContent.startsWith('Complete'),{},{timeout:30000});
  assert.equal(await site.evaluate(()=>window.count),1);
  let job=await panel.evaluate(async()=>(await chrome.storage.local.get('job')).job);assert.equal(job.frames[0].status,'done');
  let saved=await panel.evaluate(async id=>(await chrome.downloads.search({id}))[0],job.frames[0].downloadId);assert.equal(saved.state,'complete');assert.match(saved.filename,/FRAME_001__00-00-00-000__00-00-05-000.png$/);
  console.log('PASS: ChatGPT fixture connect, submit, image association, PNG download and frame naming');
  await panel.locator('#start').click();await panel.waitForTimeout(300);assert.equal(await site.evaluate(()=>window.count),1);
  console.log('PASS: completed queue does not resubmit on resume');
  const flow=await context.newPage();await flow.goto('https://labs.google/fx/tools/flow/project/fixture');
  await panel.locator('#provider').selectOption('flow');await panel.locator('#refresh').click();
  await panel.locator('#map').click();
  await flow.locator('#flow-prompt').hover();await flow.locator('#flow-prompt').click();
  await flow.locator('#generate').hover();await flow.locator('#generate').click();
  await flow.locator('#results img').hover();await flow.keyboard.press('ArrowUp');await flow.keyboard.press('Enter');
  await panel.waitForFunction(()=>document.querySelector('#status').textContent==='Controls mapped. Ready to start.');
  assert.equal(await flow.evaluate(()=>window.count),0,'mapping must not generate');
  console.log('PASS: Flow mapping stores controls without submitting a request');
  await panel.locator('#file').setInputFiles([]);await panel.locator('#file').setInputFiles(path.join(root,'sample-prompts.txt'));
  await panel.locator('#folder').fill('Fixture-Flow');await panel.locator('#flow-ready').check();await panel.locator('#start').click();
  await panel.waitForFunction(()=>document.querySelector('#status').textContent.startsWith('Complete'),{},{timeout:30000});
  assert.equal(await flow.evaluate(()=>window.count),1);
  job=await panel.evaluate(async()=>(await chrome.storage.local.get('job')).job);assert.equal(job.frames[0].status,'done');assert.equal(job.provider,'flow');
  saved=await panel.evaluate(async id=>(await chrome.downloads.search({id}))[0],job.frames[0].downloadId);assert.equal(saved.state,'complete');
  console.log('PASS: Flow baseline excludes old result, submits once and downloads new PNG');
  await panel.screenshot({path:path.join(out,'side-panel.png'),fullPage:true});
  assert.equal(await panel.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  console.log('PASS: 400px companion layout has no horizontal overflow; side-panel action configured');
 }finally{await context.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
