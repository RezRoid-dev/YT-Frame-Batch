import test from 'node:test';import assert from 'node:assert/strict';import {connect} from '../bridge.mjs';
function mock({url='https://chatgpt.com/c/test',ready=false,denied=false}={}){
 let injections=0;
 return {get injections(){return injections;},tabs:{get:async()=>({url}),sendMessage:async()=>{if(!ready)throw Error('Receiving end does not exist');return {ok:true,version:6,composer:true};}},scripting:{executeScript:async()=>{if(denied)throw Error('Site permission denied');injections++;ready=true;}}};
}
test('repairs an already-open page without receiver',async()=>{const c=mock();assert.equal((await connect(c,1,'chatgpt')).composer,true);assert.equal(c.injections,1);});
test('does not inject duplicate listener on healthy page',async()=>{const c=mock({ready:true});await connect(c,1,'chatgpt');assert.equal(c.injections,0);});
test('reports denied website permission',async()=>{await assert.rejects(()=>connect(mock({denied:true}),1,'chatgpt'),/Site access/);});
test('rejects wrong provider tab before injection',async()=>{const c=mock();await assert.rejects(()=>connect(c,1,'flow'),/Google Flow/);assert.equal(c.injections,0);});
