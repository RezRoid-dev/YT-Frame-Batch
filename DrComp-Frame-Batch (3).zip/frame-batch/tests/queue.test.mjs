import test from 'node:test';import assert from 'node:assert/strict';
test('failed queue: continue, retry one row, retry remaining failures, skip completed frames',async()=>{
 const originalNow=Date.now,originalTimeout=globalThis.setTimeout;
 let now=0;Date.now=()=>now+=1000;globalThis.setTimeout=fn=>{queueMicrotask(fn);return 1;};
 try{
  for(const provider of ['chatgpt','flow']){
   const nodes=new Map();const element=()=>({value:'',textContent:'',checked:true,children:[],append(x){this.children.push(x);},replaceChildren(...xs){this.children=xs;}});
   const $=id=>{if(!nodes.has(id))nodes.set(id,element());return nodes.get(id);};
   $('provider').value=provider;$('delay').value=10;
   globalThis.document={getElementById:$,createElement:element};globalThis.window={addEventListener(){}};globalThis.confirm=()=>true;
   Object.defineProperty(globalThis,'navigator',{configurable:true,value:{locks:{request:async(name,opts,fn)=>fn({})}}});
   const store={},calls=[],downloads=[],missingMarkers=new Set();let interrupted=true;
   const site=provider==='flow'?'https://labs.google/fx/tools/flow/project/test':'https://chatgpt.com/c/test';
   globalThis.chrome={
    storage:{local:{get:async key=>({[key]:store[key]}),set:async value=>Object.assign(store,structuredClone(value))}},
    tabs:{query:async()=>[{id:10,url:site,active:true,title:'Test provider'}],get:async()=>({url:site}),sendMessage:async(id,m)=>{
     calls.push(m);
     if(m.type==='probe')return {ok:true,version:6,composer:true,button:provider!=='chatgpt',results:true};
     if(m.type==='prepare')return {ok:true,context:provider==='flow'?{before:['old'],page:site}:null};
     if(m.type==='send')return {ok:true,sent:true};
     if(m.type==='inspect'&&missingMarkers.has(m.marker))return {ok:true,found:false,images:[]};
     if(m.type==='inspect')return {ok:true,found:true,busy:false,images:[{url:'https://chatgpt.com/image.png',width:512,height:288}]};
     if(m.type==='pixels')return {ok:true,data:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jD1sAAAAASUVORK5CYII='};
    }},scripting:{executeScript:async()=>{}},
    downloads:{download:async opts=>{downloads.push(opts);return downloads.length;},search:async({id})=>[{id,state:interrupted?'interrupted':'complete',exists:true,error:'NETWORK_FAILED'}]}
   };
   await import('../dashboard.mjs?test='+provider);
   $('file').files=[{name:'Test.txt',text:async()=>[0,1,2].map(i=>`IMAGE ${i+1}\nTIME: 00:00:${String(i*5).padStart(2,'0')}.000 --> 00:00:${String((i+1)*5).padStart(2,'0')}.000\n\nPROMPT:\nA distinct desk ${i}.`).join('\n---\n')}];
   await $('file').onchange();
   await $('start').onclick();assert.match($('status').textContent,/3 failed/);
   assert.ok(store.job.frames.every(f=>f.status==='failed'&&f.error.includes('interrupted')));
   assert.equal(calls.filter(c=>c.type==='send').length,3);
   interrupted=false;
   chrome.downloads.search=async({id})=>[{id,state:id<=3?'interrupted':'complete',exists:true}];
   const firstRetry=$('queue').children[0].children.find(n=>n.textContent==='Retry frame');
   assert.ok(firstRetry);await firstRetry.onclick();
   assert.equal(store.job.frames[0].status,'done');assert.equal(store.job.frames.filter(f=>f.status==='failed').length,2);
   missingMarkers.add(calls.filter(c=>c.type==='send')[1].marker);
   await $('retry-failed').onclick();
   assert.ok(store.job.frames.every(f=>f.status==='done'));assert.equal(store.job.provider,provider);
   assert.equal(calls.filter(c=>c.type==='send').length,4,'only the missing second output should be regenerated');
   assert.equal(downloads.length,6);assert.equal(downloads[3].filename,'Test/FRAME_001__00-00-00-000__00-00-05-000.png');
   await $('start').onclick();assert.equal(calls.filter(c=>c.type==='send').length,4);assert.equal(downloads.length,6);

  }
 }finally{Date.now=originalNow;globalThis.setTimeout=originalTimeout;}
});
